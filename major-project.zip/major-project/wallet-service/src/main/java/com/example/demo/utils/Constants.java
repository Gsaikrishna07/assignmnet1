package com.example.demo.utils;

public class Constants {

	
	public static final String USER_CREATED_TOPIC="user_created";
	public static final String TXN_INITIATED_TOPIC="txn_initiated";

	public static final String WALLET_UPDATE_TOPIC="wallet_updated";

}