package com.example.demo.models;

public enum TransactionStatus {

	PENDING,SUCCESSFUL,FAILED
}
